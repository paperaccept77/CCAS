# 输入格式示例

- `requests.jsonl`：一个请求、两个固定候选、一个历史访问；示例向量使用零值。
- `labels.jsonl`：独立的真实下一地点字段。
- `index.jsonl`：两条示例检索对象，分别供 trajectory / collaborative 角色读取。
- `warmup_scripts.jsonl`：该请求的固定候选比较任务，偏好+文本组，两次证据操作后 FINISH 和全局 STOP。
- `costs.example.json`：时间归一化单位和各操作成本上界的配置示例，calibrated 字段记录标定状态。

`python scripts/create_examples.py` 可重新生成 requests/index 两个示例文件。业务数据使用相同字段和维度，填入对应编码器的特征结果。
