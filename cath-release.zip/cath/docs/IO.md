# 输入输出约定

所有 JSONL 均为 UTF-8，每行一个 JSON 对象。`examples/` 提供字段和维度示例，示例向量使用零值；业务输入填写对应编码器的特征结果。

## 1. 请求文件 `requests.jsonl`

每条请求对应一个 episode。该文件禁止存放 `positive_poi_id`、`label`、`next_visit`、`next_visit_time`。

| 字段 | 类型 / 形状 | 含义 |
|---|---|---|
| `request_id` | string | 唯一请求 ID |
| `user_id` | string | 用户 ID |
| `cutoff` | float | 预测时刻，Unix UTC 秒 |
| `location` | `[latitude, longitude]` | 预测时已知位置 |
| `request_features` | float `[D]` | 冻结序列编码器及合法时空特征的投影结果 |
| `history` | Visit 数组 | 按时间递增，时间严格小于 cutoff；读取最后 50 次 |
| `candidates` | POI 数组，长度 K | 基检索器原始候选池，不能补入真实下一地点 |
| `base_scores` | float `[K]` | 与 candidates 顺序一致的冻结基模型分数 |

默认 `D=256`、`K=100`。接口接受任意非空 K，论文的实验配置是 100。所有张量加载为 float32，LLM 内部按配置使用 BF16。

候选 POI 字段：

| 字段 | 类型 / 形状 | 含义 |
|---|---|---|
| `poi_id`, `category` | string | 地点 ID、类别 |
| `latitude`, `longitude` | float | 经纬度 |
| `mask` | bool `[2]` | 顺序固定为 `[文本可用, 图像可用]` |
| `text` | string / null | 可用文本；缺失必须为 null |
| `image_embedding` | float `[512]` / null | 冻结 CLIP ViT-B/16 图像特征；缺失必须为 null |
| `features` | float `[256]` | 候选初始输入表示，仅 candidates 需要 |
| `content_timestamp` | float / null | 内容的可用时间，不得晚于 cutoff |
| `static_side_information` | bool | 无时间戳内容必须显式设为 true |

`Visit` 结构为 `{"timestamp": 1700000000.0, "poi": {上述 POI 字段，但不需要 features}}`。

文本/图像 mask 为 false 时，解析器拒绝非 null 的相应原始内容。**预计算 `features` 无法从数值上检查是否混入隐藏内容**：上游必须先施加人工缺失，再进行编码、缓存及索引。不能先编码完整内容再仅修改 mask。

预计算特征接口接收 SASRec、CLIP、SBERT 的编码结果。上游将序列、时间、位置及可用多模态特征投影为 D 维；请求和候选初始状态再由 `neural/ranking.py` 的可训练 MLP 编码。

## 2. 标签 `labels.jsonl`

```json
{"request_id":"example-001","positive_poi_id":"poi-b"}
```

标签只交给训练 loss/reward 或评估器。推理命令没有标签参数，`Request` 类型不含标签。真实 POI 可以不在候选池里：此时训练 ranking/PPO 跳过该请求，评估仍保留并记为零分。

## 3. 训练检索索引 `index.jsonl`（可选）

| 字段 | 类型 | 含义 |
|---|---|---|
| `object_id` | string | 检索对象 ID，分数相同按此 ID 排序 |
| `user_id` | string | 来源用户；排除当前用户 |
| `split` | `"train"` | 其他值会被拒绝 |
| `timestamp` | float | 对象可用的 Unix UTC 秒，检索时须小于 cutoff |
| `role` | `"trajectory"` / `"collaborative"` | 检索权限 |
| `category` | string | related_pois 的类别过滤键 |
| `embedding` | float `[D]` | 合法训练对象的预编码表示 |
| `text` | string | 合法训练轨迹/用户/POI 摘要 |

实现使用 cosine top-20 暴力检索，下一轮查询加入已广播的任务向量。没有索引时，相应检索操作不可用。索引内容和 embedding 也必须先掩码、再编码；`split=train` 字段本身不能替代上游数据划分审查。

## 4. 操作接口

`EvidenceTools.bind(request, task, role, operation, shared)` → `Evidence`：

- `candidate_text: dict[候选下标, list[str]]`
- `candidate_images: dict[候选下标, list[Tensor[512]]]`
- `retrieval_vectors: dict[候选下标, list[Tensor[D]]]`
- `objects: list[str]`、`status: "ok" | "empty"`

`LLMExecutor(...)` → `OperationOutput`：

| 输出 | 形状 / 类型 | 含义 |
|---|---|---|
| `messages` | dict[int, Tensor[D]] | 实际覆盖候选的向量消息，不是排序分数 |
| `summary` | Tensor[D] | 成员本次任务摘要 |
| `status` | string | ok / empty |
| `objects` | list[string] | 访问对象 ID |
| `seconds`, `normalized_cost` | float | 引擎执行后填入实测耗时及归一化成本 |
| `input_tokens`, `output_tokens` | int | 包含连续投影位置的输入长度；本实现不生成文本，输出 token 数为 0 |

## 5. 推理输出 `predictions.jsonl`

`Engine.run(Request)` → `EpisodeResult`，包括 `scores: Tensor[K]`、各已完成任务的 `task_scores`、训练用离散决策记录、可序列化 `record`。

| record 字段 | 含义 |
|---|---|
| `request_id` | 输入请求 ID |
| `candidate_ids` | 原始候选池顺序 |
| `base_scores`, `scores` | 原始顺序下的基分数、最终分数 `[K]` |
| `ranking` | 按分数递减排列的地点 ID；并列按 ID 字典序 |
| `termination` | sampled_stop / task_limit / budget / no_affordable_task / initialization_budget |
| `tasks` | 任务类型、候选下标、成员、各轮操作/覆盖/状态/访问对象/token/成本 |
| `incidence` | `[6, 已完成任务数]`，行名由 `roles` 给出 |
| `cost` | 每条记账成本之和 |
| `seconds` | 各被测块耗时之和；不是完整进程墙钟延迟 |
| `cost_ledger` | 路由、操作、聚合、初始化、排序更新的实测记录 |
| `cost_calibrated` | 成本文件是否标记为已标定 |

`scores[i]` 永远对应 `candidate_ids[i]`，`ranking` 不增删 POI。超出工具上界时抛出错误，避免继续产生超预算结果。

## 6. 训练中间产物

- `warmup_scripts.jsonl`：`request_id` 和 `actions` 字符串数组。任务键为 `request:0,1,...`、`comparison:0,1`、`compensation:0`；角色名大写；操作名小写；停止/执行为 `STOP`、`EXECUTE`。动作必须匹配当时的合法集合。达到最大组大小时强制执行，不再读取 EXECUTE。不给脚本时采样合法轨迹。
- `combinations.jsonl`：`collect-combinations` 产出的真实执行组合，包括相同上下文的 comparison_key、任务观测、成员、实测净增益、邀请决策及合法 mask。只用于选择预热，不含未执行组合的伪结果。
- checkpoint `.pt`：config、ranking model、policy、六个 LoRA 和投影/读出参数、训练阶段；选择预热另存 Q。冻结 LLM 权重不重复保存。这里保存模型权重，不保存 optimizer 或断点续训进度。
- PPO 决策（内存对象）：prediction-time observation、action、old_log_prob、value、reward、done；每个决策保留原始合法 mask。

## 7. 评估输出 `metrics.json`

`requests`、`covered`、`coverage`、`cutoff`，以及 `end_to_end`、`conditional` 下的 `recall`、`ndcg`、`mrr`。Recall/NDCG 使用指定 cutoff，MRR 不截断。覆盖率为零时 conditional 指标为 null。无重复请求、预测与标签请求 ID 集合必须相同。

在请求等权条件下：`end_to_end = coverage × conditional`。单一真实下一地点下 Recall@L 与 Hit@L 相同。
