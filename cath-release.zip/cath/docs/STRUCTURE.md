# 模块索引

所有路径相对于 `src/cath/`。各包的 `__init__.py` 导出公共接口。

| 路径 | 职责 | 主要接口 |
|---|---|---|
| `config.py` | 模型、预算和训练配置 | `Config` |
| `types.py` | 请求、候选、任务和 episode 状态 | `Request`, `POI`, `Visit`, `Task`, `Role`, `OperationOutput` |
| `data/jsonl.py` | JSONL 文件读取与写入 | `read_jsonl`, `write_jsonl` |
| `data/validation.py` | 张量、内容时间和 mask 检查 | `vector`, `parse_poi` |
| `data/requests.py` | 请求解析和请求流 | `parse_request`, `requests` |
| `data/labels.py` | 独立标签读取 | `labels` |
| `neural/layers.py` | 共享全连接组件 | `mlp` |
| `neural/set_encoder.py` | 集合自注意力与池化 | `SetEncoder` |
| `neural/ranking.py` | 消息融合、状态更新和分数修正 | `RankingModel` |
| `policy/records.py` | 观测及离散决策记录 | `Observation`, `Decision` |
| `policy/features.py` | 策略环境特征 | `global_features`, `selected_features` |
| `policy/network.py` | 动作分布、集合条件和 critic | `Policy` |
| `tools/evidence.py` | 候选关联证据 | `Evidence` |
| `tools/geometry.py` | 球面距离 | `kilometers` |
| `tools/index.py` | 训练记录检索 | `TrainingIndex` |
| `tools/permissions.py` | 角色和内容的可用操作 | `operations`, `eligible` |
| `tools/binding.py` | 角色证据构造 | `bind` |
| `tools/registry.py` | 工具统一入口 | `EvidenceTools` |
| `executor/backbone.py` | 本地模型和 LoRA 构造 | `load_backbone` |
| `executor/model.py` | 输入投影和向量读出 | `LLMExecutor` |
| `cost/profile.py` | 成本归一化和操作上界 | `CostProfile` |
| `cost/ledger.py` | 计时、预留、结算 | `Ledger` |
| `engine/records.py` | 推理结果容器 | `EpisodeResult` |
| `engine/tasks.py` | 任务、成员资格和最小执行预算 | `legal_tasks`, `eligible_roles`, `execution_reserve` |
| `engine/observations.py` | 各决策层的动作与 mask | `task_observation`, `member_observation`, `operation_observation` |
| `engine/rounds.py` | 同步成员执行、消息更新和广播 | `execute_task` |
| `engine/episode.py` | 请求级决策循环与输出记录 | `run` |
| `engine/core.py` | 推理统一入口 | `Engine` |
| `training/objectives.py` | 排序 utility | `utility` |
| `training/phases.py` | 参数训练阶段 | `set_phase` |
| `training/warmup.py` | 执行器排序预热 | `warmup_loss` |
| `training/rewards.py` | 任务收益与成本 | `assign_rewards` |
| `training/advantages.py` | 优势及回报估计 | `gae` |
| `training/ppo.py` | 策略和 critic 优化 | `ppo_update` |
| `training/evaluator.py` | 已执行集合收益回归 | `SetEvaluator`, `fit_set_evaluator` |
| `training/records.py` | 组合训练记录 | `CombinationRecord` |
| `training/selection.py` | 邀请策略预热 | `initialize_invitations` |
| `training/runner.py` | 训练命令的阶段调度 | `train` |
| `combinations/codec.py` | 观测和组合记录序列化 | `encode_record`, `decode_record` |
| `combinations/collector.py` | 匹配条件下的组合执行 | `collect` |
| `cli/parser.py` | CLI 参数 | `build_parser` |
| `cli/infer.py` | 推理文件流 | `infer` |
| `cli/collect.py` | 组合采集命令 | `collect_combinations` |
| `cli/evaluate.py` | 指标输出命令 | `evaluate_predictions` |
| `cli/main.py` | 命令分发 | `main` |
| `runtime.py` | 配置、随机种子、模型组装和权重恢复 | `build` |
| `checkpoints.py` | 模型与 adapter 权重保存 | `save_checkpoint` |
| `metrics.py` | 覆盖率和排名指标 | `evaluate` |

## 公共导入

```python
from cath.config import Config
from cath.data import parse_request, requests, labels
from cath.engine import Engine, EpisodeResult
from cath.neural import RankingModel, SetEncoder
from cath.policy import Policy, Observation, Decision
from cath.executor import LLMExecutor
from cath.tools import EvidenceTools
from cath.training import warmup_loss, assign_rewards, ppo_update
```
