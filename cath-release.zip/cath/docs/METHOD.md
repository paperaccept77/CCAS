# 算法实现

## 任务与成员选择

任务包含类型和候选下标集合：请求状态更新覆盖全部候选，候选比较使用当前排名相邻对及同类别相邻对，语义补偿使用缺失文本或图像的单个候选。

策略先选择任务或 STOP，再选择 initiator。邀请头对已选成员进行集合编码，逐次选择合法成员或 EXECUTE。每个任务对应一条超边，成员在任务执行期间固定。

| 机制 | 模块 |
|---|---|
| 任务生成、角色资格与执行预算 | `engine/tasks.py` |
| 任务/成员/操作的合法 mask | `engine/observations.py` |
| 策略动作和 critic | `policy/network.py` |
| 全局状态与已选集合特征 | `policy/features.py` |
| 顺序决策、终止及超图记录 | `engine/episode.py` |

## 证据执行

角色权限绑定到历史、当前候选和训练检索对象。所有历史时间早于请求 cutoff；带时间戳的内容须在 cutoff 前可用，无时间戳内容通过静态侧信息字段标识。

每轮成员从同一快照选择操作，然后联合预留成本并执行。最新 `(role, target)` 消息覆盖旧消息。集合编码器聚合候选消息，GRU 更新候选任务状态；没有消息的候选保留原任务向量。广播结果只进入本任务成员的局部状态。

| 机制 | 模块 |
|---|---|
| 角色操作权限 | `tools/permissions.py` |
| 角色证据绑定、历史筛选和目标属性 | `tools/binding.py` |
| 训练对象检索与 top-20 选择 | `tools/index.py` |
| 证据容器、地理距离 | `tools/evidence.py`, `tools/geometry.py` |
| 本地骨干和六个角色 adapter | `executor/backbone.py` |
| 连续特征投影及候选/摘要读出 | `executor/model.py` |
| 同轮准入、执行、聚合和广播 | `engine/rounds.py` |

骨干采用 Llama-3.1-8B-Instruct，LoRA 插入 `q_proj`、`v_proj`，rank=16、alpha=32、dropout=0。文本以 token 输入，图像及检索向量以连续投影输入。候选和摘要读出位置位于序列尾，证据按候选分配 token 配额；默认输入上限 4096。执行接口返回向量消息。

检索查询由候选表示和已广播任务向量确定，使用 cosine 相似度，按对象 ID 处理并列。`related_pois` 先进行类别过滤。历史范围、比较目标及其他工具参数由确定性规则绑定。

## 排序与状态

任务完成后更新参与者的请求级记忆和目标候选状态；请求更新任务同时更新全局上下文。每条请求重新初始化记忆。

共享排序头计算：

```text
score = base_score + g(current_context, current_candidate, initial_candidate, mask)
                   - g(initial_context, initial_candidate, initial_candidate, mask)
```

初始修正相消，初始参考保留在预热梯度图中。补偿任务更新排序表示并保留原始缺失 mask。重复处理可通过循环状态更新改变表示。

模型位于 `neural/ranking.py`。集合编码器位于 `neural/set_encoder.py`，采用两层四头自注意力和可学习 seed pooling；MLP 中间维度为 D。

## 训练

| 阶段 | 目标与流程 | 模块 |
|---|---|---|
| 排序预热 | 在固定离散轨迹的已完成任务状态上最小化真实下一地点的负 log-probability | `training/warmup.py`, `training/objectives.py` |
| 组合采集 | 相同初始状态/task/initiator 下执行成员组合；每个成员最多两次实质操作 | `combinations/collector.py` |
| 集合评估器 | 对已执行组合的实测净收益进行回归 | `training/evaluator.py` |
| 邀请初始化 | 模仿同条件下优选已执行组的合法邀请序列 | `training/selection.py` |
| PPO | 固定执行器与排序模型，保留原始观测和 mask 进行 clipped policy/value 更新 | `training/ppo.py` |
| 奖励与优势 | 每个任务最终决策获得 utility delta−cost；gamma=1 的 GAE | `training/rewards.py`, `training/advantages.py` |
| 阶段及优化器 | 参数冻结、batch 采样、梯度累计和 checkpoint 保存 | `training/phases.py`, `training/runner.py` |

排序预热默认 AdamW、学习率 1e-4、1000 步升温、batch 64、20k 步。策略默认学习率 3e-5、gradient clip=1.0。PPO clip=0.2、GAE lambda=0.95、entropy weight=0.01、value weight=0.5、4 epochs。

utility 为真实下一地点在固定池上的 log-softmax。标签由 loss/reward 计算器读取，策略与工具使用预测时可用输入。全局 STOP 仅产生决策成本；强制终止保持已有状态，不添加虚构 STOP。

## 成本与评估

`cost/profile.py` 定义时间归一化单位和成本上界；`cost/ledger.py` 维护预留、实测和结算。操作按上界升序准入，整轮联合预留，结算时归还差额。被测块包括初始化、路由、操作、聚合与排序更新；CUDA 设备在计时边界同步。`seconds` 为被测块耗时之和。

配置 `exchange=false` 时，各成员仅用自己的消息更新局部分析，任务完成后使用统一融合与排序接口。

`metrics.py` 计算 coverage、条件和端到端 Recall/NDCG/MRR。每条请求权重相同，固定池漏检计零；端到端指标等于覆盖率乘以条件指标。
