# CATH：下一地点推荐的任务超图智能体组

**Complementary Agents via Task Hypergraphs for Next-POI Recommendation**

基于 Python/PyTorch 的下一地点推荐框架。对应论文：*Learning Complementary Agent Groups via Task Hypergraphs for Next-POI Recommendation with Missing Modalities*。

代码实现请求级任务选择、六角色组形成、多轮共享证据、超图状态更新、候选重排，以及排序预热、已执行组合选择预热和固定执行器 PPO。输入包括预计算特征、本地模型权重和硬件成本配置。

## 文件结构

```text
.
├── src/cath/
│   ├── types.py          # Request / Task / Role / OperationOutput
│   ├── data/             # JSONL、请求解析、标签和特征校验
│   ├── neural/           # MLP、集合编码器和共享排序模型
│   ├── policy/           # 观测记录、环境特征和策略网络
│   ├── tools/            # 角色权限、证据绑定、地理特征和训练索引
│   ├── executor/         # 骨干模型、角色 LoRA 和连续读出
│   ├── cost/             # 成本配置、计时和预算账本
│   ├── engine/           # 任务规划、动作观测、轮次和 episode
│   ├── training/         # 目标、预热、奖励、GAE、PPO 和集合评估器
│   ├── combinations/     # 组合采集和记录序列化
│   ├── cli/              # 参数解析和各命令入口
│   ├── runtime.py        # 模型及运行组件构建
│   ├── checkpoints.py    # 模型与 adapter 权重保存
│   ├── config.py         # 模型与算法配置
│   └── metrics.py        # 覆盖率和排名指标
├── configs/paper.json    # 论文默认设置及明确的实现默认值
├── examples/             # 请求、标签、索引和成本文件示例
├── docs/IO.md            # 字段、张量维度、模型和文件输入输出
├── docs/METHOD.md        # 算法机制和训练配置
├── docs/STRUCTURE.md     # 模块职责与公共接口
├── scripts/              # 示例生成、项目检查和源码打包
└── pyproject.toml
```

## 输入与输出

**输入**：预测时刻之前的访问历史、已知时间/位置、冻结检索器给出的固定候选及分数、可用文本/图像特征和缺失 mask、可选训练检索索引、预算及成本上界。

**输出**：同一候选池的最终分数和排名，以及任务成员、轮次、操作、覆盖范围、访问对象、token 和成本记录。推理输入不含真实下一地点标签。

| 阶段 | 输入文件 | 输出 |
|---|---|---|
| Executor 排序预热 | train requests + 独立 labels + 可选动作脚本 | ranking / LoRA / 投影权重 |
| 组合采集 | 预热权重 + train requests/labels + 固定 task/initiator | combinations JSONL |
| 选择预热 | 组合记录 + 预热权重 | Q 及初始化 policy 权重 |
| PPO | 选择预热权重 + train requests/labels | 固定 executor 下学习的 policy |
| 推理 | requests + checkpoint + 可选 index + costs | predictions JSONL |
| 评估 | predictions + 独立 labels | 覆盖率、条件/端到端 Recall、NDCG、MRR |

详细定义：[输入输出](docs/IO.md) · [算法实现](docs/METHOD.md) · [模块索引](docs/STRUCTURE.md)。

## 安装与本地模型

要求 Python 3.10+。依赖区间定义在 `pyproject.toml`。

```sh
pip install -e .
```

默认 `models/Llama-3.1-8B-Instruct` 为**本地** Transformers 模型/tokenizer 目录，可修改配置中的 backbone 路径。SASRec、CLIP、SBERT 特征按 IO 文档预先导出。

`examples/requests.jsonl` 使用 D=256、图像 512 维的零值向量演示格式，包含两个候选；论文设置 K=100。成本文件字段参见 `examples/costs.example.json`，在 `configs/costs.local.json` 中填写当前硬件的时间单位及各操作成本上界。

## 命令示例

以下命令使用 JSONL 输入及本地模型权重。`configs/costs.local.json` 指定时间归一化单位及路由、操作、聚合和排序更新的成本上界。

排序预热（默认 20k 外层步，batch 64，LR 1e-4）：

```sh
cath train --stage warmup --requests data/train.requests.jsonl --labels data/train.labels.jsonl --index data/train.index.jsonl --costs configs/costs.local.json --output checkpoints/warmup.pt
```

可加 `--scripts data/warmup_scripts.jsonl` 固定合法离散轨迹；否则采样合法轨迹。`examples/warmup_scripts.jsonl` 演示候选 0/1 的偏好+文本组，包含两轮证据操作和一轮 FINISH。

组合选择预热（在相同初始状态、task、initiator 下，采集包含 initiator 的可执行组合）：

```sh
cath collect-combinations --checkpoint checkpoints/warmup.pt --requests data/train.requests.jsonl --labels data/train.labels.jsonl --index data/train.index.jsonl --costs configs/costs.local.json --task comparison:0,1 --initiator PREFERENCE --repetitions 3 --output outputs/combinations.jsonl
cath train --stage selection --checkpoint checkpoints/warmup.pt --combinations outputs/combinations.jsonl --costs configs/costs.local.json --steps 1000 --output checkpoints/selection.pt
```

`comparison:0,1` 必须是各请求当时的合法比较对；可将采集范围限定为具有该合法对的请求子集，或调用 Python API 为每条请求选择合法任务。组合记录与 executor 权重绑定；executor 改动后重新采集。仅训练集记录可用于 Q 和邀请模仿。

固定执行器 PPO：

```sh
cath train --stage ppo --checkpoint checkpoints/selection.pt --requests data/train.requests.jsonl --labels data/train.labels.jsonl --index data/train.index.jsonl --costs configs/costs.local.json --output checkpoints/cath.pt
```

推理与评估：

```sh
cath infer --checkpoint checkpoints/cath.pt --requests data/test.requests.jsonl --index data/train.index.jsonl --costs configs/costs.local.json --output outputs/predictions.jsonl
cath evaluate --predictions outputs/predictions.jsonl --labels data/test.labels.jsonl --cutoff 20 --output outputs/metrics.json
```

默认使用 `--config configs/paper.json --device cuda`。CPU 可显式设置 `--device cpu` 并选择适合的模型精度配置。读取 checkpoint 时配置须一致。

评估漏检请求保留为零分；候选池保持原始检索结果。checkpoint 保存训练阶段的模型参数；验证集通过同一推理接口和独立标签按 NDCG@20 选择权重。

## 静态检查

```sh
python scripts/check_static.py
```

检查范围包括 Python 语法、本地模块导入、JSON/JSONL 格式、示例维度和成本字段。
