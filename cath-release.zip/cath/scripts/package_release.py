"""Assemble the CATH source distribution directory and ZIP archive."""
import shutil
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


DIRECTORIES = ("src", "configs", "examples", "docs", "scripts")
FILES = ("README.md", "pyproject.toml", "MANIFEST.in", ".gitignore", ".gitattributes")


def main():
    root = Path(__file__).resolve().parents[1]
    target = root / "release/cath"
    archive = target.parent / "cath-release.zip"
    if target.exists() or archive.exists():
        raise FileExistsError("release/cath or release/cath-release.zip already exists")
    target.mkdir(parents=True)
    for name in DIRECTORIES:
        shutil.copytree(root / name, target / name,
                        ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "*.egg-info"))
    for name in FILES:
        shutil.copy2(root / name, target / name)
    with ZipFile(archive, "w", ZIP_DEFLATED) as bundle:
        for path in sorted(target.rglob("*")):
            if path.is_file():
                bundle.write(path, path.relative_to(target.parent).as_posix())
    print(f"Source directory: {target}")
    print(f"Source archive: {archive}")


if __name__ == "__main__":
    main()
